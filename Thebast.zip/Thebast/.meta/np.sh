echo "
   1) device scan
   2) check port
   3) web scan port
   4) nmap install
"
  read -p "===+>" w
  if [ $w -eq 4 ]; then
    pkg install nmap
    clear
   fi



    if [ $w -eq 3 ]; then
    pkg install nmap
    clear
    read -p "enter the websit ip: " n
    nmap -v ${n}
fi


if [ $w -eq 2 ]; then
    #statements
    # this is nmap
    # 0.1v
    # 45

    pkg install nmap
   clear
read -p "enter the target ip:\n " T
    nmap -v ${T}
  fi

     if [ $w -eq 1 ]; then
     pkg install nmap
     clear
     read -p  "enter the target ip:=>  " r
     nmap -v ${r}
    fi
