masseg = 'NO number'

echo "
        1) btf attack facebook
        2) phone number btf
        3) facebook free"
        read -p "num~~~~~~~~>>>" g
        if [[ $g -eq 1 ]]; then
                cd .facebook
                pkg install python
                pkg install python2
                python2 fb.py
        fi
        if [[ $g -eq 2 ]]; then
                cd .facebook
                python2 oopp.py
        fi
        if [[ $g -eq 3 ]]; then
        cd .facebook
        python2 EgyCracker.py 
        fi
