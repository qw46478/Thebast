echo "
[1]Facebook.apk
[2]Instagram.apk
[3]Messenger.apk
[4]WhatsApp.apk
[5]virus.apk
[6]exit

"
read -p "num~~~~~~~>>" w
if [ $w -eq 1 ]; then 
cp Facebook.apk /sdcard/apk
sleep 2
clear

sleep 0.5
echo "Loading 0%";
sleep 1
clear
echo "Loading 10%";
sleep 1
clear
echo "Loading 20% ";
sleep 1
clear
echo "Loading 30% ";
sleep 1
clear
echo "Loading 40% ";
sleep 1
clear
echo "Loading 50% ";
sleep 1
clear
echo "Loading 60% ";
sleep 1
clear
echo "Loading 70% ";
sleep 1
clear
echo "Loading 80% ";
sleep 1
clear
echo "Loading 84% ";
sleep 1
clear
echo "Loading 86% ";
sleep 1
clear
echo "Loading 89% ";
sleep 1
clear
echo "Loading 92% ";
sleep 1
clear
echo "Loading 97% ";
sleep 1
clear
echo "Loading 99% ";
sleep 1
clear

echo "Loading 100% "
echo "
"
fi 
if [ $w -eq 2 ]; then
cp Instagram.apk /sdcard/apk
sleep 2
clear

sleep 0.5
echo "Loading 0%";
sleep 1
clear
echo "Loading 10%";
sleep 1
clear
echo "Loading 20% ";
sleep 1
clear
echo "Loading 30% ";
sleep 1
clear
echo "Loading 40% ";
sleep 1
clear
echo "Loading 50% ";
sleep 1
clear
echo "Loading 60% ";
sleep 1
clear
echo "Loading 70% ";
sleep 1
clear
echo "Loading 80% ";
sleep 1
clear
echo "Loading 84% ";
sleep 1
clear
echo "Loading 86% ";
sleep 1
clear
echo "Loading 89% ";
sleep 1
clear
echo "Loading 92% ";
sleep 1
clear
echo "Loading 97% ";
sleep 1
clear
echo "Loading 99% ";
sleep 1
clear

echo "Loading 100% "
echo "
"
fi
if [ $w -eq 3 ]; then
cp Messenger.apk /sdcard/apk
sleep 2
clear

sleep 0.5
echo "Loading 0%";
sleep 1
clear
echo "Loading 10%";
sleep 1
clear
echo "Loading 20% ";
sleep 1
clear
echo "Loading 30% ";
sleep 1
clear
echo "Loading 40% ";
sleep 1
clear
echo "Loading 50% ";
sleep 1
clear
echo "Loading 60% ";
sleep 1
clear
echo "Loading 70% ";
sleep 1
clear
echo "Loading 80% ";
sleep 1
clear
echo "Loading 84% ";
sleep 1
clear
echo "Loading 86% ";
sleep 1
clear
echo "Loading 89% ";
sleep 1
clear
echo "Loading 92% ";
sleep 1
clear
echo "Loading 97% ";
sleep 1
clear
echo "Loading 99% ";
sleep 1
clear

echo "Loading 100% "
echo "
"
fi
if [ $w -eq 4 ]; then
cp WhatsApp.apk /sdcard/apk
sleep 2
clear

sleep 0.5
echo "Loading 0%";
sleep 1
clear
echo "Loading 10%";
sleep 1
clear
echo "Loading 20% ";
sleep 1
clear
echo "Loading 30% ";
sleep 1
clear
echo "Loading 40% ";
sleep 1
clear
echo "Loading 50% ";
sleep 1
clear
echo "Loading 60% ";
sleep 1
clear
echo "Loading 70% ";
sleep 1
clear
echo "Loading 80% ";
sleep 1
clear
echo "Loading 84% ";
sleep 1
clear
echo "Loading 86% ";
sleep 1
clear
echo "Loading 89% ";
sleep 1
clear
echo "Loading 92% ";
sleep 1
clear
echo "Loading 97% ";
sleep 1
clear
echo "Loading 99% ";
sleep 1
clear

echo "Loading 100% "
echo "
"
fi
if [ $w -eq 5 ]; then
cp virus.apk /sdcard/apk
sleep 2
clear

sleep 0.5
echo "Loading 0%";
sleep 1
clear
echo "Loading 10%";
sleep 1
clear
echo "Loading 20% ";
sleep 1
clear
echo "Loading 30% ";
sleep 1
clear
echo "Loading 40% ";
sleep 1
clear
echo "Loading 50% ";
sleep 1
clear
echo "Loading 60% ";
sleep 1
clear
echo "Loading 70% ";
sleep 1
clear
echo "Loading 80% ";
sleep 1
clear
echo "Loading 84% ";
sleep 1
clear
echo "Loading 86% ";
sleep 1
clear
echo "Loading 89% ";
sleep 1
clear
echo "Loading 90% ";
sleep 1
clear

echo "Loading 100% "
echo "
"
fi
